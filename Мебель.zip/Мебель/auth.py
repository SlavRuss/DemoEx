import sqlite3
import pandas as pd
import streamlit as st

def authenticate_user(login, password):
    conn = sqlite3.connect('my_furniture_database.sql')
    query = "select id, full_name, role from users where email = ? and password = ?"
    df = pd.read_sql_query(query, conn, params=[login, password])
    conn.close()
    if not df.empty:
        return df.iloc[0].to_dict()
    return None

def login(login, password):
    user = authenticate_user(login, password)
    if user:
        st.session_state['authenticated'] = True
        st.session_state['user_id'] = user['id']
        st.session_state['user_name'] = user['full_name']
        st.session_state['user_role'] = user['role']
        return True
    return False

def logout():
    for key in ['authenticated', 'user_id', 'user_name', 'user_role']:
        if key in st.session_state:
            del st.session_state[key]

def is_authenticated():
    return st.session_state.get('authenticated', False)

def get_current_user():
    if is_authenticated():
        return {
            'id': st.session_state['user_id'],
            'name': st.session_state['user_name'],
            'role': st.session_state['user_role']
        }
    return None