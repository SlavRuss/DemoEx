import streamlit as st
import pandas as pd
import os
from PIL import Image
from db import get_products, get_categories, get_manufacturers, get_suppliers, delete_product
from components import format_product_row, get_discount_range_options, get_sort_options

def show_products():
    st.title("Товары")
    
    user_role = st.session_state.get('user_role', 'guest')
    
    if user_role == 'admin':
        if st.button("+ Добавить товар", use_container_width=False):
            st.session_state['show_product_form'] = 'add'
            st.session_state['product_edit_id'] = None
            st.rerun()
    
    filters = {}
    sort_by = None
    
    if user_role in ['admin', 'manager']:
        st.subheader("Фильтры и сортировка")
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            discount_filter = st.selectbox("Скидка", get_discount_range_options())
            if discount_filter != 'Все диапазоны':
                filters['discount_range'] = discount_filter
        
        with col2:
            search_term = st.text_input("Поиск", placeholder="Название, категория, описание...")
            if search_term:
                filters['search'] = search_term
        
        with col3:
            sort_by = st.selectbox("Сортировка", get_sort_options())
            if sort_by == 'Цена (возр.)':
                sort_by = 'price_asc'
            elif sort_by == 'Цена (убыв.)':
                sort_by = 'price_desc'
            elif sort_by == 'Количество (возр.)':
                sort_by = 'stock_asc'
            elif sort_by == 'Количество (убыв.)':
                sort_by = 'stock_desc'
            else:
                sort_by = None
    
    df = get_products(filters if filters else None, sort_by)
    
    if df.empty:
        st.info("Нет данных для отображения")
        return
    
    st.subheader("Список товаров")
    
    for idx, row in df.iterrows():
        with st.container():
            cols = st.columns([1, 2, 2, 1, 1, 1])
            
            photo_path = row['photo_path']
            if photo_path and os.path.exists(photo_path):
                try:
                    image = Image.open(photo_path)
                    image.thumbnail((100, 100))
                    cols[0].image(image, width=100)
                except:
                    if os.path.exists("picture.png"):
                        cols[0].image("picture.png", width=100)
                    else:
                        cols[0].write("Нет фото")
            else:
                if os.path.exists("picture.png"):
                    cols[0].image("picture.png", width=100)
                else:
                    cols[0].write("Нет фото")
            
            cols[1].write(f"**{row['product_name']}**")
            cols[1].write(f"*{row['category_name']}*")
            desc_text = str(row['description']) if row['description'] else ""
            cols[1].write(f"{desc_text[:50]}..." if len(desc_text) > 50 else desc_text)
            
            cols[2].write(f"Производитель: {row['manufacturer_name']}")
            cols[2].write(f"Поставщик: {row['supplier_name']}")
            cols[2].write(f"Ед.изм: {row['unit']}")
            cols[2].write(f"Остаток: {row['stock_quantity']} шт.")
            
            if row['discount'] > 0:
                cols[3].write(f"<span style='text-decoration: line-through; color: red;'>{row['price']:.2f} руб.</span>", unsafe_allow_html=True)
                cols[3].write(f"<span style='color: black;'><strong>{row['final_price']:.2f} руб.</strong></span>", unsafe_allow_html=True)
                cols[3].write(f"Скидка: {row['discount']}%")
            else:
                cols[3].write(f"<strong>{row['price']:.2f} руб.</strong>", unsafe_allow_html=True)
            
            if user_role == 'admin':
                col_btn1, col_btn2 = cols[4], cols[5]
                if col_btn1.button(f"Ред.", key=f"edit_{row['id']}"):
                    st.session_state['show_product_form'] = 'edit'
                    st.session_state['product_edit_id'] = row['id']
                    st.rerun()
                if col_btn2.button(f"Удалить", key=f"del_{row['id']}"):
                    success = delete_product(row['id'])
                    if success:
                        st.success("Товар удалён")
                        st.rerun()
                    else:
                        st.error("Нельзя удалить товар, который есть в заказах")
            
            st.markdown("---")
    
    if 'show_product_form' in st.session_state:
        from pages.product_form import show_product_form
        show_product_form()