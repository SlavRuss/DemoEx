import streamlit as st
from db import get_orders, get_order_items

def show_orders():
    st.title("Заказы")
    
    user_role = st.session_state.get('user_role', 'guest')
    
    if user_role not in ['admin', 'manager']:
        st.error("У вас нет прав для просмотра заказов")
        return
    
    df = get_orders()
    
    if df.empty:
        st.info("Нет данных для отображения")
        return
    
    st.subheader("Список заказов")
    
    for idx, row in df.iterrows():
        with st.expander(f"Заказ {row['order_number']} от {row['order_date']} - {row['order_status']}"):
            st.write(f"**Клиент:** {row['customer_full_name']}")
            st.write(f"**Код получения:** {row['pickup_code']}")
            st.write(f"**Дата доставки:** {row['delivery_date'] if row['delivery_date'] else 'Не указана'}")
            st.write(f"**Количество товаров:** {row['items_count']}")
            st.write(f"**Итоговая сумма:** {row['total_amount']:.2f} руб.")
            
            st.subheader("Состав заказа")
            items = get_order_items(row['id'])
            if not items.empty:
                st.dataframe(items[['product_name', 'quantity', 'price_at_time', 'total']], use_container_width=True, hide_index=True)