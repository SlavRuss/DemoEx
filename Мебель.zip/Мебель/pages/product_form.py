import streamlit as st
import pandas as pd
import os
from PIL import Image
from db import get_product_by_id, get_categories, get_manufacturers, get_suppliers, add_product, update_product, get_old_photo_path, get_products

PHOTO_SIZE = (300, 200)
PHOTO_DIR = "product_photos"

if not os.path.exists(PHOTO_DIR):
    os.makedirs(PHOTO_DIR)

def save_photo(uploaded_file, product_id):
    if uploaded_file is not None:
        old_photo = get_old_photo_path(product_id)
        if old_photo and os.path.exists(old_photo):
            os.remove(old_photo)
        
        ext = uploaded_file.name.split('.')[-1]
        filename = f"product_{product_id}.{ext}"
        filepath = os.path.join(PHOTO_DIR, filename)
        
        image = Image.open(uploaded_file)
        image.thumbnail(PHOTO_SIZE)
        image.save(filepath)
        
        return filepath
    return None

def show_product_form():
    user_role = st.session_state.get('user_role', 'guest')
    
    if user_role != 'admin':
        st.error("У вас нет прав для этого действия")
        return
    
    mode = st.session_state.get('show_product_form')
    product_id = st.session_state.get('product_edit_id')
    
    if mode == 'edit' and 'product_form_open' in st.session_state:
        st.warning("Форма редактирования уже открыта")
        if st.button("Закрыть текущую форму"):
            del st.session_state['product_form_open']
            st.rerun()
        return
    
    if mode == 'edit':
        st.session_state['product_form_open'] = True
    
    st.title("Редактирование товара" if mode == 'edit' else "Добавление товара")
    
    product = None
    if mode == 'edit' and product_id:
        product = get_product_by_id(product_id)
        if product is None:
            st.error("Товар не найден")
            if st.button("Назад"):
                del st.session_state['show_product_form']
                st.rerun()
            return
    
    categories = get_categories()
    manufacturers = get_manufacturers()
    suppliers = get_suppliers()
    
    category_options = {c['category_name']: c['id'] for c in categories}
    manufacturer_options = {m['manufacturer_name']: m['id'] for m in manufacturers}
    supplier_options = {s['supplier_name']: s['id'] for s in suppliers}
    
    with st.form(key='product_form'):
        if product is not None:
            default_name = product['product_name']
            default_category = [k for k, v in category_options.items() if v == product['category_id']]
            default_category = default_category[0] if default_category else list(category_options.keys())[0]
            default_description = product['description'] if product['description'] else ""
            default_manufacturer = [k for k, v in manufacturer_options.items() if v == product['manufacturer_id']]
            default_manufacturer = default_manufacturer[0] if default_manufacturer else list(manufacturer_options.keys())[0]
            default_supplier = [k for k, v in supplier_options.items() if v == product['supplier_id']]
            default_supplier = default_supplier[0] if default_supplier else list(supplier_options.keys())[0]
            default_price = float(product['price'])
            default_unit = product['unit'] if product['unit'] else "шт"
            default_stock = int(product['stock_quantity'])
            default_discount = float(product['discount'])
            default_photo_path = product['photo_path']
        else:
            default_name = ""
            default_category = list(category_options.keys())[0]
            default_description = ""
            default_manufacturer = list(manufacturer_options.keys())[0]
            default_supplier = list(supplier_options.keys())[0]
            default_price = 0.0
            default_unit = "шт"
            default_stock = 0
            default_discount = 0.0
            default_photo_path = None
        
        product_name = st.text_input("Наименование товара*", value=default_name)
        
        category_name = st.selectbox("Категория*", options=list(category_options.keys()), index=list(category_options.keys()).index(default_category))
        
        description = st.text_area("Описание", value=default_description)
        
        manufacturer_name = st.selectbox("Производитель*", options=list(manufacturer_options.keys()), index=list(manufacturer_options.keys()).index(default_manufacturer))
        
        supplier_name = st.selectbox("Поставщик*", options=list(supplier_options.keys()), index=list(supplier_options.keys()).index(default_supplier))
        
        col1, col2 = st.columns(2)
        with col1:
            price = st.number_input("Цена*", min_value=0.0, value=default_price, step=100.0, format="%.2f")
        with col2:
            unit = st.text_input("Единица измерения", value=default_unit)
        
        col3, col4 = st.columns(2)
        with col3:
            stock_quantity = st.number_input("Количество на складе", min_value=0, value=default_stock, step=1)
        with col4:
            discount = st.number_input("Скидка (%)", min_value=0.0, max_value=100.0, value=default_discount, step=1.0, format="%.1f")
        
        uploaded_photo = st.file_uploader("Фото товара", type=['jpg', 'jpeg', 'png'])
        
        if default_photo_path and os.path.exists(default_photo_path):
            st.image(default_photo_path, width=150)
            st.caption("Текущее фото")
        
        submitted = st.form_submit_button("Сохранить")
        
        if submitted:
            errors = []
            if not product_name:
                errors.append("Наименование товара обязательно")
            if not category_name:
                errors.append("Категория обязательна")
            if not manufacturer_name:
                errors.append("Производитель обязателен")
            if not supplier_name:
                errors.append("Поставщик обязателен")
            if price < 0:
                errors.append("Цена не может быть отрицательной")
            if stock_quantity < 0:
                errors.append("Количество не может быть отрицательным")
            
            if errors:
                for error in errors:
                    st.error(error)
            else:
                category_id = category_options[category_name]
                manufacturer_id = manufacturer_options[manufacturer_name]
                supplier_id = supplier_options[supplier_name]
                
                if mode == 'add':
                    add_product(product_name, category_id, description, manufacturer_id, supplier_id, price, unit, stock_quantity, discount, None)
                    st.success("Товар добавлен")
                    
                    new_products = get_products()
                    if not new_products.empty:
                        new_id = new_products.iloc[-1]['id']
                        if uploaded_photo:
                            photo_path = save_photo(uploaded_photo, new_id)
                            if photo_path:
                                update_product(new_id, product_name, category_id, description, manufacturer_id, supplier_id, price, unit, stock_quantity, discount, photo_path)
                else:
                    photo_path = None
                    if uploaded_photo:
                        photo_path = save_photo(uploaded_photo, product_id)
                    update_product(product_id, product_name, category_id, description, manufacturer_id, supplier_id, price, unit, stock_quantity, discount, photo_path)
                    st.success("Товар обновлён")
                
                if 'product_form_open' in st.session_state:
                    del st.session_state['product_form_open']
                del st.session_state['show_product_form']
                if 'product_edit_id' in st.session_state:
                    del st.session_state['product_edit_id']
                st.rerun()
    
    col_btn1, col_btn2 = st.columns([1,5])
    with col_btn1:
        if st.button("Отмена"):
            if 'product_form_open' in st.session_state:
                del st.session_state['product_form_open']
            del st.session_state['show_product_form']
            if 'product_edit_id' in st.session_state:
                del st.session_state['product_edit_id']
            st.rerun()