import sqlite3
import pandas as pd
import os

def get_connection():
    return sqlite3.connect('my_furniture_database.sql', check_same_thread=False)

def get_categories():
    conn = get_connection()
    query = "select id, category_name from categories order by category_name"
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df.to_dict('records')

def get_manufacturers():
    conn = get_connection()
    query = "select id, manufacturer_name from manufacturers order by manufacturer_name"
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df.to_dict('records')

def get_suppliers():
    conn = get_connection()
    query = "select id, supplier_name from suppliers order by supplier_name"
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df.to_dict('records')

def get_products(filters=None, sort_by=None):
    conn = get_connection()
    query = """
    select 
        p.id,
        p.product_name,
        c.category_name,
        p.description,
        m.manufacturer_name,
        s.supplier_name,
        p.price,
        p.unit,
        p.stock_quantity,
        p.discount,
        p.photo_path,
        round(p.price * (100 - p.discount) / 100, 2) as final_price
    from products p
    left join categories c on p.category_id = c.id
    left join manufacturers m on p.manufacturer_id = m.id
    left join suppliers s on p.supplier_id = s.id
    where 1=1
    """
    params = []
    if filters:
        if filters.get('discount_range') and filters['discount_range'] != 'Все диапазоны':
            if filters['discount_range'] == '0-10.99%':
                query += " and p.discount < 11"
            elif filters['discount_range'] == '11-14.99%':
                query += " and p.discount >= 11 and p.discount < 15"
            elif filters['discount_range'] == '15% и более':
                query += " and p.discount >= 15"
        if filters.get('search'):
            query += " and (p.product_name like ? or c.category_name like ? or p.description like ? or m.manufacturer_name like ? or s.supplier_name like ?)"
            search_term = f"%{filters['search']}%"
            params.extend([search_term, search_term, search_term, search_term, search_term])
    query += " order by "
    if sort_by == 'price_asc':
        query += "final_price asc"
    elif sort_by == 'price_desc':
        query += "final_price desc"
    elif sort_by == 'stock_asc':
        query += "p.stock_quantity asc"
    elif sort_by == 'stock_desc':
        query += "p.stock_quantity desc"
    else:
        query += "p.id"
    df = pd.read_sql_query(query, conn, params=params)
    conn.close()
    return df

def get_orders():
    conn = get_connection()
    query = """
    select 
        o.id,
        o.order_number,
        o.order_date,
        o.delivery_date,
        o.customer_full_name,
        o.pickup_code,
        o.order_status,
        count(oi.id) as items_count,
        sum(oi.quantity * oi.price_at_time) as total_amount
    from orders o
    left join order_items oi on o.id = oi.order_id
    group by o.id
    order by o.order_date desc
    """
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df

def get_order_items(order_id):
    conn = get_connection()
    query = """
    select 
        oi.id,
        p.product_name,
        oi.quantity,
        oi.price_at_time,
        (oi.quantity * oi.price_at_time) as total
    from order_items oi
    left join products p on oi.product_id = p.id
    where oi.order_id = ?
    """
    df = pd.read_sql_query(query, conn, params=[order_id])
    conn.close()
    return df

def get_product_by_id(product_id):
    conn = get_connection()
    query = """
    select 
        p.id,
        p.product_name,
        p.category_id,
        p.description,
        p.manufacturer_id,
        p.supplier_id,
        p.price,
        p.unit,
        p.stock_quantity,
        p.discount,
        p.photo_path
    from products p
    where p.id = ?
    """
    df = pd.read_sql_query(query, conn, params=[product_id])
    conn.close()
    return df.iloc[0] if not df.empty else None

def add_product(product_name, category_id, description, manufacturer_id, supplier_id, price, unit, stock_quantity, discount, photo_path):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        insert into products (product_name, category_id, description, manufacturer_id, supplier_id, price, unit, stock_quantity, discount, photo_path)
        values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (product_name, category_id, description, manufacturer_id, supplier_id, price, unit, stock_quantity, discount, photo_path))
    conn.commit()
    conn.close()

def update_product(product_id, product_name, category_id, description, manufacturer_id, supplier_id, price, unit, stock_quantity, discount, photo_path):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        update products 
        set product_name = ?, category_id = ?, description = ?, manufacturer_id = ?, supplier_id = ?, price = ?, unit = ?, stock_quantity = ?, discount = ?, photo_path = ?
        where id = ?
    """, (product_name, category_id, description, manufacturer_id, supplier_id, price, unit, stock_quantity, discount, photo_path, product_id))
    conn.commit()
    conn.close()

def delete_product(product_id):
    conn = get_connection()
    cursor = conn.cursor()
    check_query = "select count(*) as count from order_items where product_id = ?"
    df = pd.read_sql_query(check_query, conn, params=[product_id])
    if df.iloc[0]['count'] > 0:
        conn.close()
        return False
    cursor.execute("delete from products where id = ?", (product_id,))
    conn.commit()
    conn.close()
    return True

def get_old_photo_path(product_id):
    conn = get_connection()
    query = "select photo_path from products where id = ?"
    df = pd.read_sql_query(query, conn, params=[product_id])
    conn.close()
    return df.iloc[0]['photo_path'] if not df.empty else None