import streamlit as st
import pandas as pd
from db import get_project_by_id, get_clients, get_managers, add_project, update_project, get_active_tasks_by_project
from components import get_status_options
from auth import check_role

def show_project_form():
    if not (check_role('admin') or check_role('manager')):
        st.error("У вас нет прав для этого действия")
        return
    
    mode = st.session_state.get('show_project_form')
    project_id = st.session_state.get('project_edit_id')
    
    st.title("Редактирование проекта" if mode == 'edit' else "Добавление проекта")
    
    project = None
    if mode == 'edit' and project_id:
        project = get_project_by_id(project_id)
        if project is None:
            st.error("Проект не найден")
            if st.button("Назад"):
                del st.session_state['show_project_form']
                st.rerun()
            return
    
    clients = get_clients()
    managers = get_managers()
    
    client_options = {c['client_name']: c['id'] for c in clients}
    manager_options = {m['full_name']: m['id'] for m in managers}
    
    if project is not None:
        default_name = project['project_name']
        default_client = project['client_name']
        default_manager = project['manager_name']
        default_start = pd.to_datetime(project['start_date']) if project['start_date'] else None
        default_end = pd.to_datetime(project['end_date']) if project['end_date'] else None
        default_status = project['status']
        default_budget = int(project['budget']) if project['budget'] else 0
        default_completion = int(project['completion_percent']) if project['completion_percent'] else 0
    else:
        default_name = ""
        default_client = list(client_options.keys())[0] if client_options else ""
        default_manager = list(manager_options.keys())[0] if manager_options else ""
        default_start = None
        default_end = None
        default_status = get_status_options()[0]
        default_budget = 0
        default_completion = 0
    
    with st.form(key='project_form'):
        project_name = st.text_input("Название проекта*", value=default_name)
        
        client_name = st.selectbox(
            "Клиент*",
            options=list(client_options.keys()),
            index=list(client_options.keys()).index(default_client) if default_client in client_options else 0
        )
        
        manager_name = st.selectbox(
            "Менеджер*",
            options=list(manager_options.keys()),
            index=list(manager_options.keys()).index(default_manager) if default_manager in manager_options else 0
        )
        
        col1, col2 = st.columns(2)
        with col1:
            start_date = st.date_input("Дата начала*", value=default_start)
        
        with col2:
            end_date = st.date_input("Дата окончания*", value=default_end)
        
        status = st.selectbox("Статус*", get_status_options(), index=get_status_options().index(default_status) if default_status in get_status_options() else 0)
        
        budget = st.number_input("Бюджет", min_value=0, value=default_budget, step=10000)
        
        completion_percent = st.slider("Процент выполнения", 0, 100, value=default_completion)
        
        submitted = st.form_submit_button("Сохранить")
        
        if submitted:
            errors = []
            if not project_name:
                errors.append("Название проекта обязательно")
            if not client_name:
                errors.append("Клиент обязателен")
            if not manager_name:
                errors.append("Менеджер обязателен")
            if not start_date:
                errors.append("Дата начала обязательна")
            if not end_date:
                errors.append("Дата окончания обязательна")
            if end_date and start_date and end_date < start_date:
                errors.append("Дата окончания не может быть раньше даты начала")
            if budget < 0:
                errors.append("Бюджет не может быть отрицательным")
            
            if errors:
                for error in errors:
                    st.error(error)
            else:
                client_id = client_options[client_name]
                manager_id = manager_options[manager_name]
                
                if mode == 'add':
                    add_project(project_name, client_id, manager_id, str(start_date), str(end_date), status, budget, completion_percent)
                    st.success("Проект добавлен")
                else:
                    if status == 'Завершён' and project is not None and project['status'] != 'Завершён':
                        active_tasks = get_active_tasks_by_project(project_id)
                        if active_tasks > 0:
                            st.warning(f"В проекте {active_tasks} незавершённых задач. Завершите их перед закрытием проекта")
                        else:
                            update_project(project_id, project_name, client_id, manager_id, str(start_date), str(end_date), status, budget, completion_percent)
                            st.success("Проект обновлён")
                    else:
                        update_project(project_id, project_name, client_id, manager_id, str(start_date), str(end_date), status, budget, completion_percent)
                        st.success("Проект обновлён")
                
                del st.session_state['show_project_form']
                if 'project_edit_id' in st.session_state:
                    del st.session_state['project_edit_id']
                st.rerun()
    
    col_btn1, col_btn2 = st.columns([1,5])
    with col_btn1:
        if st.button("Отмена"):
            del st.session_state['show_project_form']
            if 'project_edit_id' in st.session_state:
                del st.session_state['project_edit_id']
            st.rerun()