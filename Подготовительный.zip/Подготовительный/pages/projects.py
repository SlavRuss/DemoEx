import streamlit as st
import pandas as pd
from db import get_projects, get_clients, get_managers, delete_project, get_active_tasks_by_project
from components import format_project_row, get_status_options, show_user_info
from auth import check_role

def show_projects():
    st.title("Проекты")
    
    user_role = st.session_state.get('user_role', 'guest')
    
    if check_role('admin') or check_role('manager'):
        if st.button("+ Добавить проект", use_container_width=False):
            st.session_state['show_project_form'] = 'add'
            st.session_state['project_edit_id'] = None
            st.rerun()
    
    filters = {}
    
    if check_role('admin') or check_role('manager'):
        st.subheader("Фильтры и сортировка")
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            status_filter = st.selectbox("Статус", ['Все значения'] + get_status_options())
            if status_filter != 'Все значения':
                filters['status'] = status_filter
        
        with col2:
            search_term = st.text_input("Поиск", placeholder="Название, клиент, менеджер...")
            if search_term:
                filters['search'] = search_term
        
        with col3:
            sort_by = st.selectbox("Сортировать по", ['Без сортировки', 'Бюджет (возр.)', 'Бюджет (убыв.)'])
        
        with col4:
            st.write("")
    
    df = get_projects(filters if filters else {})
    
    if sort_by == 'Бюджет (возр.)' and not df.empty:
        df = df.sort_values('budget', ascending=True)
    elif sort_by == 'Бюджет (убыв.)' and not df.empty:
        df = df.sort_values('budget', ascending=False)
    
    if df.empty:
        st.info("Нет данных для отображения")
        return
    
    st.subheader("Список проектов")
    
    styled_df = df.style.apply(format_project_row, axis=1)
    st.dataframe(styled_df, use_container_width=True, hide_index=True)
    
    if check_role('admin') or check_role('manager'):
        st.subheader("Управление проектами")
        
        for idx, row in df.iterrows():
            col1, col2, col3 = st.columns([3,1,1])
            with col1:
                st.write(f"**{row['project_name']}**")
            with col2:
                if st.button(f"Редактировать", key=f"edit_{row['id']}"):
                    st.session_state['show_project_form'] = 'edit'
                    st.session_state['project_edit_id'] = row['id']
                    st.rerun()
            with col3:
                if st.button(f"Удалить", key=f"del_{row['id']}"):
                    active_tasks = get_active_tasks_by_project(row['id'])
                    if active_tasks > 0:
                        st.error(f"Нельзя удалить проект. В нём есть {active_tasks} активных задач")
                    else:
                        delete_project(row['id'])
                        st.success("Проект удалён")
                        st.rerun()
            st.markdown("---")
    
    if 'show_project_form' in st.session_state:
        from pages.project_form import show_project_form
        show_project_form()