import streamlit as st
import sqlite3
import pandas as pd
from db import get_employees, get_active_tasks_by_employee
from auth import check_role

def show_employees():
    if not check_role('admin'):
        st.error("У вас нет прав для этого действия")
        return
    
    st.title("Сотрудники")
    
    employees = get_employees()
    
    if not employees:
        st.info("Нет данных")
        return
    
    df = pd.DataFrame(employees)
    st.dataframe(df, use_container_width=True, hide_index=True)
    
    st.subheader("Управление сотрудниками")
    
    for emp in employees:
        col1, col2 = st.columns([3,1])
        with col1:
            st.write(f"**{emp['full_name']}**")
        with col2:
            if st.button(f"Удалить", key=f"del_emp_{emp['id']}"):
                active_tasks = get_active_tasks_by_employee(emp['id'])
                if active_tasks > 0:
                    st.error(f"Нельзя удалить сотрудника. У него {active_tasks} активных задач. Сначала переназначьте задачи")
                else:
                    conn = sqlite3.connect('my_preparatory_database.sql')
                    cursor = conn.cursor()
                    cursor.execute("delete from employees where id = ?", (emp['id'],))
                    conn.commit()
                    conn.close()
                    st.success("Сотрудник удалён")
                    st.rerun()
        st.markdown("---")