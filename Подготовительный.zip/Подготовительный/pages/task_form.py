import streamlit as st
import pandas as pd
from db import get_task_by_id, get_projects, get_employees, add_task, update_task
from components import get_task_status_options, get_priority_options
from auth import check_role, get_current_user

def show_task_form():
    user_role = st.session_state.get('user_role', 'guest')
    current_user = get_current_user()
    
    if not (check_role('admin') or check_role('manager') or user_role == 'employee'):
        st.error("У вас нет прав для этого действия")
        return
    
    mode = st.session_state.get('show_task_form')
    task_id = st.session_state.get('task_edit_id')
    
    st.title("Редактирование задачи" if mode == 'edit' else "Добавление задачи")
    
    task = None
    if mode == 'edit' and task_id:
        task = get_task_by_id(task_id)
        if task is None:
            st.error("Задача не найдена")
            if st.button("Назад"):
                del st.session_state['show_task_form']
                st.rerun()
            return
        
        if user_role == 'employee' and current_user is not None and task['assigned_to_id'] != current_user['id']:
            st.error("Вы можете редактировать только свои задачи")
            if st.button("Назад"):
                del st.session_state['show_task_form']
                st.rerun()
            return
    
    projects_df = get_projects()
    employees_list = get_employees()
    
    if projects_df.empty:
        st.error("Нет доступных проектов")
        return
    
    project_options = {row['project_name']: row['id'] for idx, row in projects_df.iterrows()}
    employee_options = {e['full_name']: e['id'] for e in employees_list}
    
    with st.form(key='task_form'):
        default_name = task['task_name'] if task is not None else ""
        task_name = st.text_input("Название задачи*", value=default_name)
        
        if task is not None and task['project_name'] in project_options:
            default_project_index = list(project_options.keys()).index(task['project_name'])
        else:
            default_project_index = 0
        
        project_name = st.selectbox(
            "Проект*",
            options=list(project_options.keys()),
            index=default_project_index
        )
        
        if task is not None and task['assigned_to_name'] in employee_options:
            default_employee_index = list(employee_options.keys()).index(task['assigned_to_name'])
        else:
            default_employee_index = 0
        
        employee_name = st.selectbox(
            "Исполнитель*",
            options=list(employee_options.keys()),
            index=default_employee_index
        )
        
        if task is not None and task['priority'] in get_priority_options():
            default_priority_index = get_priority_options().index(task['priority'])
        else:
            default_priority_index = 0
        
        priority = st.selectbox("Приоритет*", get_priority_options(), index=default_priority_index)
        
        if task is not None and task['status'] in get_task_status_options():
            default_status_index = get_task_status_options().index(task['status'])
        else:
            default_status_index = 0
        
        status = st.selectbox("Статус*", get_task_status_options(), index=default_status_index)
        
        if task is not None and task['deadline']:
            default_deadline = pd.to_datetime(task['deadline'])
        else:
            default_deadline = None
        
        deadline = st.date_input("Дедлайн*", value=default_deadline)
        
        default_description = task['description'] if task is not None else ""
        description = st.text_area("Описание", value=default_description)
        
        submitted = st.form_submit_button("Сохранить")
        
        if submitted:
            errors = []
            if not task_name:
                errors.append("Название задачи обязательно")
            if not project_name:
                errors.append("Проект обязателен")
            if not employee_name:
                errors.append("Исполнитель обязателен")
            if not deadline:
                errors.append("Дедлайн обязателен")
            
            if errors:
                for error in errors:
                    st.error(error)
            else:
                project_id = project_options[project_name]
                employee_id = employee_options[employee_name]
                
                if mode == 'add':
                    add_task(task_name, project_id, employee_id, priority, status, str(deadline), description)
                    st.success("Задача добавлена")
                else:
                    update_task(task_id, task_name, project_id, employee_id, priority, status, str(deadline), description)
                    st.success("Задача обновлена")
                
                del st.session_state['show_task_form']
                if 'task_edit_id' in st.session_state:
                    del st.session_state['task_edit_id']
                st.rerun()
    
    col_btn1, col_btn2 = st.columns([1,5])
    with col_btn1:
        if st.button("Отмена"):
            del st.session_state['show_task_form']
            if 'task_edit_id' in st.session_state:
                del st.session_state['task_edit_id']
            st.rerun()