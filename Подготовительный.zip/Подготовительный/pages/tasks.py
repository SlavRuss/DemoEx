import streamlit as st
import pandas as pd
from db import get_tasks, get_projects, get_employees, delete_task, update_task, get_active_tasks_by_employee
from components import format_task_row, get_task_status_options, get_priority_options
from auth import check_role, get_current_user

def show_tasks():
    st.title("Задачи")
    
    user_role = st.session_state.get('user_role', 'guest')
    current_user = get_current_user()
    
    if check_role('admin') or check_role('manager'):
        if st.button("+ Добавить задачу", use_container_width=False):
            st.session_state['show_task_form'] = 'add'
            st.session_state['task_edit_id'] = None
            st.rerun()
    
    filters = {}
    
    if check_role('admin') or check_role('manager'):
        st.subheader("Фильтры и сортировка")
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            status_filter = st.selectbox("Статус", ['Все значения'] + get_task_status_options())
            if status_filter != 'Все значения':
                filters['status'] = status_filter
        
        with col2:
            priority_filter = st.selectbox("Приоритет", ['Все значения'] + get_priority_options())
            if priority_filter != 'Все значения':
                filters['priority'] = priority_filter
        
        with col3:
            employees = get_employees()
            employee_names = ['Все значения'] + [e['full_name'] for e in employees]
            assigned_filter = st.selectbox("Исполнитель", employee_names)
            if assigned_filter != 'Все значения':
                filters['assigned_to'] = assigned_filter
        
        with col4:
            search_term = st.text_input("Поиск", placeholder="Название, проект, описание...")
            if search_term:
                filters['search'] = search_term
        
        with col5:
            sort_by = st.selectbox("Сортировать по", ['Без сортировки', 'Дедлайн (возр.)', 'Дедлайн (убыв.)', 'Приоритет'])
    
    df = get_tasks(filters if filters else {})
    
    if not check_role('admin') and not check_role('manager') and user_role == 'employee':
        df = df[df['assigned_to'] == current_user['name']]
    
    if sort_by == 'Дедлайн (возр.)' and not df.empty:
        df = df.sort_values('deadline', ascending=True)
    elif sort_by == 'Дедлайн (убыв.)' and not df.empty:
        df = df.sort_values('deadline', ascending=False)
    elif sort_by == 'Приоритет' and not df.empty:
        priority_order = {'Критический': 1, 'Высокий': 2, 'Средний': 3, 'Низкий': 4}
        df['priority_num'] = df['priority'].map(priority_order)
        df = df.sort_values('priority_num')
        df = df.drop('priority_num', axis=1)
    
    if df.empty:
        st.info("Нет данных для отображения")
        return
    
    st.subheader("Список задач")
    
    styled_df = df.style.apply(format_task_row, axis=1)
    st.dataframe(styled_df, use_container_width=True, hide_index=True)
    
    if check_role('admin') or check_role('manager') or user_role == 'employee':
        st.subheader("Управление задачами")
        
        for idx, row in df.iterrows():
            col1, col2, col3 = st.columns([3,1,1])
            with col1:
                st.write(f"**{row['task_name']}** - {row['project_name']}")
            with col2:
                if st.button(f"Редактировать", key=f"edit_{row['id']}"):
                    st.session_state['show_task_form'] = 'edit'
                    st.session_state['task_edit_id'] = row['id']
                    st.rerun()
            with col3:
                if check_role('admin') or check_role('manager'):
                    if st.button(f"Удалить", key=f"del_{row['id']}"):
                        delete_task(row['id'])
                        st.success("Задача удалена")
                        st.rerun()
            st.markdown("---")
    
    if 'show_task_form' in st.session_state:
        from pages.task_form import show_task_form
        show_task_form()