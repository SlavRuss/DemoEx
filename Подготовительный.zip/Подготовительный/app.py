import streamlit as st
from auth import is_authenticated, logout
from components import apply_custom_style
from pages import projects, tasks

st.set_page_config(page_title="Управление проектами", layout="wide", page_icon=None)

apply_custom_style()

if 'page' not in st.session_state:
    st.session_state['page'] = 'login'

def show_login():
    st.title("Вход в систему")
    
    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        login_input = st.text_input("Логин (email)")
        password_input = st.text_input("Пароль", type="password")
        
        col_btn1, col_btn2 = st.columns(2)
        with col_btn1:
            if st.button("Войти", use_container_width=True):
                from auth import login
                if login(login_input, password_input):
                    st.session_state['page'] = 'main'
                    st.rerun()
                else:
                    st.error("Неверный логин или пароль")
        with col_btn2:
            if st.button("Войти как гость", use_container_width=True):
                st.session_state['authenticated'] = True
                st.session_state['user_role'] = 'guest'
                st.session_state['user_name'] = 'Гость'
                st.session_state['page'] = 'main'
                st.rerun()

def show_main():
    if not is_authenticated() and st.session_state.get('user_role') != 'guest':
        st.session_state['page'] = 'login'
        st.rerun()
    
    col_header1, col_header2 = st.columns([4,1])
    with col_header2:
        if 'user_name' in st.session_state:
            st.markdown(f"<p style='text-align: right; margin-top: 10px;'><strong>{st.session_state['user_name']}</strong></p>", unsafe_allow_html=True)
    
    st.sidebar.title("Навигация")
    
    st.sidebar.markdown("---")
    
    if st.sidebar.button("Проекты", use_container_width=True):
        st.session_state['current_view'] = 'projects'
        st.rerun()
    
    if st.sidebar.button("Задачи", use_container_width=True):
        st.session_state['current_view'] = 'tasks'
        st.rerun()
    
    if st.sidebar.button("Сотрудники", use_container_width=True):
        st.session_state['current_view'] = 'employees'
        st.rerun()
    
    if st.sidebar.button("Выход на главный экран", use_container_width=True):
        st.session_state['page'] = 'main'
        if 'current_view' in st.session_state:
            del st.session_state['current_view']
        st.rerun()
    
    st.sidebar.markdown("---")
    
    if st.sidebar.button("Выйти из аккаунта", use_container_width=True):
        logout()
        st.session_state['page'] = 'login'
        st.session_state['user_role'] = None
        st.rerun()
    
    st.title("Панель управления")
    
    user_role = st.session_state.get('user_role', 'guest')
    st.info(f"Роль: {user_role}")
    
    if 'current_view' not in st.session_state:
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Проекты", "10")
        with col2:
            st.metric("Задачи", "10")
        
        st.markdown("---")
        st.subheader("Быстрый доступ")
        
        if st.button("Перейти к проектам"):
            st.session_state['current_view'] = 'projects'
            st.rerun()
        
        if st.button("Перейти к задачам"):
            st.session_state['current_view'] = 'tasks'
            st.rerun()
    else:
        if st.session_state['current_view'] == 'projects':
            projects.show_projects()
        elif st.session_state['current_view'] == 'tasks':
            tasks.show_tasks()
        elif st.session_state['current_view'] == 'employees':
            from pages.employees import show_employees
            show_employees()

def main():
    if st.session_state['page'] == 'login':
        show_login()
    elif st.session_state['page'] == 'main':
        show_main()

if __name__ == "__main__":
    main()