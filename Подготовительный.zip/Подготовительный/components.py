import streamlit as st
import pandas as pd
from datetime import datetime

def apply_custom_style():
    st.markdown("""
        <style>
        .stApp {
            border-radius: 0px;
        }
        .stButton > button {
            border-radius: 0px;
        }
        .stTextInput > div > div > input {
            border-radius: 0px;
        }
        .stSelectbox > div > div > select {
            border-radius: 0px;
        }
        .stDateInput > div > div > input {
            border-radius: 0px;
        }
        .stDataFrame {
            border-radius: 0px;
        }
        div[data-testid="stMetricValue"] {
            border-radius: 0px;
        }
        </style>
    """, unsafe_allow_html=True)

def format_project_row(row):
    status = row['status']
    completion = row['completion_percent']
    if status == 'На паузе':
        return ['background-color: #FFA500'] * len(row)
    elif completion == 100:
        return ['background-color: #2E8B57'] * len(row)
    else:
        return [''] * len(row)

def format_task_row(row):
    priority = row['priority']
    deadline = row['deadline']
    status = row['status']
    task_name = row['task_name']
    
    styles = ['' for _ in range(len(row))]
    
    if priority == 'Критический':
        styles = ['background-color: #DC143C' for _ in range(len(row))]
    
    if deadline and status != 'Выполнена':
        try:
            deadline_date = datetime.strptime(deadline, '%Y-%m-%d').date()
            if deadline_date < datetime.now().date():
                styles[0] = 'text-decoration: line-through; color: red'
        except:
            pass
    
    return styles

def show_user_info():
    if 'user_name' in st.session_state:
        st.sidebar.markdown(f"**{st.session_state['user_name']}**")
        if st.sidebar.button("Выход"):
            from auth import logout
            logout()
            st.rerun()

def get_status_options():
    return ['Новый', 'В работе', 'На паузе', 'Завершён', 'Отменён']

def get_task_status_options():
    return ['Открыта', 'В работе', 'На проверке', 'Выполнена']

def get_priority_options():
    return ['Низкий', 'Средний', 'Высокий', 'Критический']