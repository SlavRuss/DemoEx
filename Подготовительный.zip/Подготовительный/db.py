import sqlite3
import pandas as pd

def get_connection():
    return sqlite3.connect('my_preparatory_database.sql', check_same_thread=False)

def get_clients():
    conn = get_connection()
    query = "select id, client_name from clients order by client_name"
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df.to_dict('records')

def get_employees():
    conn = get_connection()
    query = "select id, full_name from employees order by full_name"
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df.to_dict('records')

def get_managers():
    conn = get_connection()
    query = "select id, full_name from employees where role = 'manager' order by full_name"
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df.to_dict('records')

def get_projects(filters=None):
    conn = get_connection()
    query = """
    select 
        p.id,
        p.project_name,
        c.client_name,
        e.full_name as manager_name,
        p.start_date,
        p.end_date,
        p.status,
        p.budget,
        p.completion_percent
    from projects p
    left join clients c on p.client_id = c.id
    left join employees e on p.manager_id = e.id
    where 1=1
    """
    params = []
    if filters:
        if filters.get('status') and filters['status'] != 'Все значения':
            query += " and p.status = ?"
            params.append(filters['status'])
        if filters.get('search'):
            query += " and (p.project_name like ? or c.client_name like ? or e.full_name like ?)"
            search_term = f"%{filters['search']}%"
            params.extend([search_term, search_term, search_term])
    query += " order by p.id"
    df = pd.read_sql_query(query, conn, params=params)
    conn.close()
    return df

def get_tasks(filters=None):
    conn = get_connection()
    query = """
    select 
        t.id,
        t.task_name,
        p.project_name,
        e.full_name as assigned_to,
        t.priority,
        t.status,
        t.deadline,
        t.description
    from tasks t
    left join projects p on t.project_id = p.id
    left join employees e on t.assigned_to_id = e.id
    where 1=1
    """
    params = []
    if filters:
        if filters.get('status') and filters['status'] != 'Все значения':
            query += " and t.status = ?"
            params.append(filters['status'])
        if filters.get('priority') and filters['priority'] != 'Все значения':
            query += " and t.priority = ?"
            params.append(filters['priority'])
        if filters.get('assigned_to') and filters['assigned_to'] != 'Все значения':
            query += " and e.full_name = ?"
            params.append(filters['assigned_to'])
        if filters.get('search'):
            query += " and (t.task_name like ? or p.project_name like ? or e.full_name like ? or t.description like ?)"
            search_term = f"%{filters['search']}%"
            params.extend([search_term, search_term, search_term, search_term])
    query += " order by t.id"
    df = pd.read_sql_query(query, conn, params=params)
    conn.close()
    return df

def get_project_by_id(project_id):
    conn = get_connection()
    query = """
    select 
        p.id,
        p.project_name,
        c.id as client_id,
        c.client_name,
        e.id as manager_id,
        e.full_name as manager_name,
        p.start_date,
        p.end_date,
        p.status,
        p.budget,
        p.completion_percent
    from projects p
    left join clients c on p.client_id = c.id
    left join employees e on p.manager_id = e.id
    where p.id = ?
    """
    df = pd.read_sql_query(query, conn, params=[project_id])
    conn.close()
    return df.iloc[0] if not df.empty else None

def get_task_by_id(task_id):
    conn = get_connection()
    query = """
    select 
        t.id,
        t.task_name,
        t.project_id,
        p.project_name,
        t.assigned_to_id,
        e.full_name as assigned_to_name,
        t.priority,
        t.status,
        t.deadline,
        t.description
    from tasks t
    left join employees e on t.assigned_to_id = e.id
    left join projects p on t.project_id = p.id
    where t.id = ?
    """
    df = pd.read_sql_query(query, conn, params=[task_id])
    conn.close()
    return df.iloc[0] if not df.empty else None

def add_project(project_name, client_id, manager_id, start_date, end_date, status, budget, completion_percent):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        insert into projects (project_name, client_id, manager_id, start_date, end_date, status, budget, completion_percent)
        values (?, ?, ?, ?, ?, ?, ?, ?)
    """, (project_name, client_id, manager_id, start_date, end_date, status, budget, completion_percent))
    conn.commit()
    conn.close()

def update_project(project_id, project_name, client_id, manager_id, start_date, end_date, status, budget, completion_percent):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        update projects 
        set project_name = ?, client_id = ?, manager_id = ?, start_date = ?, end_date = ?, status = ?, budget = ?, completion_percent = ?
        where id = ?
    """, (project_name, client_id, manager_id, start_date, end_date, status, budget, completion_percent, project_id))
    conn.commit()
    conn.close()

def delete_project(project_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("delete from projects where id = ?", (project_id,))
    conn.commit()
    conn.close()

def add_task(task_name, project_id, assigned_to_id, priority, status, deadline, description):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        insert into tasks (task_name, project_id, assigned_to_id, priority, status, deadline, description)
        values (?, ?, ?, ?, ?, ?, ?)
    """, (task_name, project_id, assigned_to_id, priority, status, deadline, description))
    conn.commit()
    conn.close()

def update_task(task_id, task_name, project_id, assigned_to_id, priority, status, deadline, description):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        update tasks 
        set task_name = ?, project_id = ?, assigned_to_id = ?, priority = ?, status = ?, deadline = ?, description = ?
        where id = ?
    """, (task_name, project_id, assigned_to_id, priority, status, deadline, description, task_id))
    conn.commit()
    conn.close()

def delete_task(task_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("delete from tasks where id = ?", (task_id,))
    conn.commit()
    conn.close()

def get_active_tasks_by_project(project_id):
    conn = get_connection()
    query = "select count(*) as count from tasks where project_id = ? and status != 'Выполнена'"
    df = pd.read_sql_query(query, conn, params=[project_id])
    conn.close()
    return df.iloc[0]['count'] if not df.empty else 0

def get_active_tasks_by_employee(employee_id):
    conn = get_connection()
    query = "select count(*) as count from tasks where assigned_to_id = ? and status != 'Выполнена'"
    df = pd.read_sql_query(query, conn, params=[employee_id])
    conn.close()
    return df.iloc[0]['count'] if not df.empty else 0