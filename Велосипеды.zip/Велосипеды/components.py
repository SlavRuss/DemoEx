import streamlit as st
from datetime import datetime

def apply_custom_style():
    st.markdown("""
        <style>
        .stApp {
            border-radius: 0px;
        }
        .stButton > button {
            border-radius: 0px;
        }
        .stTextInput > div > div > input {
            border-radius: 0px;
        }
        .stSelectbox > div > div > select {
            border-radius: 0px;
        }
        .stDateInput > div > div > input {
            border-radius: 0px;
        }
        .stDataFrame {
            border-radius: 0px;
        }
        div[data-testid="stMetricValue"] {
            border-radius: 0px;
        }
        </style>
    """, unsafe_allow_html=True)

def format_product_row(row):
    discount = row['discount']
    stock = row['stock_quantity']
    styles = ['' for _ in range(len(row))]
    if discount > 15:
        styles = ['background-color: #483D8B' for _ in range(len(row))]
    if stock == 0:
        styles = ['background-color: #808080' for _ in range(len(row))]
    return styles

def get_discount_range_options():
    return ['Все диапазоны', '0-11.99%', '12-18.99%', '19% и более']

def get_sort_options():
    return ['Без сортировки', 'Цена (возр.)', 'Цена (убыв.)', 'Название (А-Я)']