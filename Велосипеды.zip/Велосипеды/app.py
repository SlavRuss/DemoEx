import streamlit as st
from auth import is_authenticated, logout
from components import apply_custom_style
from pages import products, orders

st.set_page_config(page_title="Веломагазин", layout="wide", page_icon=None)

apply_custom_style()

if 'page' not in st.session_state:
    st.session_state['page'] = 'login'


#функция отображения окна входа с полями логин пароль и кнопкой входа гость
def show_login():
    st.title("Вход в систему")
    
    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        login_input = st.text_input("Логин")
        password_input = st.text_input("Пароль", type="password")
        
        col_btn1, col_btn2 = st.columns(2)
        with col_btn1:
            if st.button("Войти", use_container_width=True):
                from auth import login
                if login(login_input, password_input):
                    st.session_state['page'] = 'main'
                    st.rerun()
                else:
                    st.error("Неверный логин или пароль")
        with col_btn2:
            if st.button("Войти как гость", use_container_width=True):
                st.session_state['authenticated'] = True
                st.session_state['user_role'] = 'guest'
                st.session_state['user_name'] = 'Гость'
                st.session_state['page'] = 'main'
                st.rerun()


# функция приложения после авторизации для навигации и отображения фио
def show_main():
    if not is_authenticated() and st.session_state.get('user_role') != 'guest':
        st.session_state['page'] = 'login'
        st.rerun()
    
    col_header1, col_header2 = st.columns([4,1])
    with col_header2:
        if 'user_name' in st.session_state:
            st.markdown(f"<p style='text-align: right; margin-top: 10px;'><strong>{st.session_state['user_name']}</strong></p>", unsafe_allow_html=True)
    
    st.sidebar.title("Веломагазин")
    
    st.sidebar.markdown("---")
    
    if st.sidebar.button("Товары", use_container_width=True):
        st.session_state['current_view'] = 'products'
        st.rerun()
    
    user_role = st.session_state.get('user_role', 'guest')
    if check_role('admin') or check_role('manager'):
        if st.sidebar.button("Заказы", use_container_width=True):
            st.session_state['current_view'] = 'orders'
            st.rerun()
    
    if st.sidebar.button("Выход на главный экран", use_container_width=True):
        st.session_state['page'] = 'main'
        if 'current_view' in st.session_state:
            del st.session_state['current_view']
        st.rerun()
    
    st.sidebar.markdown("---")
    
    if st.sidebar.button("Выйти из аккаунта", use_container_width=True):
        logout()
        st.session_state['page'] = 'login'
        st.session_state['user_role'] = None
        st.rerun()
    
    st.title("Добро пожаловать в Веломагазин")
    
    if 'current_view' not in st.session_state:
        st.info("Выберите раздел в боковом меню")
    else:
        if st.session_state['current_view'] == 'products':
            products.show_products()
        elif st.session_state['current_view'] == 'orders':
            orders.show_orders()

# проверка роли пользователя для ограничения доступа 
def check_role(required_role):
    user_role = st.session_state.get('user_role', 'guest')
    if required_role == 'admin':
        return user_role == 'admin'
    elif required_role == 'manager':
        return user_role in ['manager', 'admin']
    elif required_role == 'client':
        return user_role in ['client', 'manager', 'admin']
    return False

def main():
    if st.session_state['page'] == 'login':
        show_login()
    elif st.session_state['page'] == 'main':
        show_main()

if __name__ == "__main__":
    main()